<?php
/*
Plugin Name: OpenRouter Chat Shortcode
Description: Adds a chat interface using the OpenRouter Qwen model via a shortcode.
Version: 1.0
Author: Dakota
*/

if (!defined('ABSPATH')) {
    exit;
}

define('OPENROUTER_CHAT_PATH', plugin_dir_path(__FILE__));
define('OPENROUTER_CHAT_URL', plugin_dir_url(__FILE__));

// Register Shortcode
add_shortcode('openrouter_chat', 'render_openrouter_chat_shortcode');

function render_openrouter_chat_shortcode() {
    ob_start(); // Start output buffering
    ?>
    <div id="openrouter-chat-container">
        <div id="chat-box" style="height: 300px; overflow-y: auto; border: 1px solid #ccc; padding: 10px;"></div>
        <input type="text" id="user-message" placeholder="Type your message here..." style="width: 100%; margin-top: 10px; padding: 5px;" />
        <button id="send-message" style="margin-top: 10px;">Send</button>
    </div>
    <?php
    return ob_get_clean(); // Return the buffered content
}

// Enqueue Scripts and Styles
add_action('wp_enqueue_scripts', 'enqueue_openrouter_chat_assets');

function enqueue_openrouter_chat_assets() {
    wp_enqueue_style('openrouter-chat-style', OPENROUTER_CHAT_URL . 'assets/css/style.css');
    wp_enqueue_script('openrouter-chat-script', OPENROUTER_CHAT_URL . 'assets/js/chat.js', array('jquery'), null, true);

    // Pass AJAX URL and nonce to the script
    wp_localize_script('openrouter-chat-script', 'openrouter_chat_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('openrouter_chat_nonce'),
    ));
}

// Handle AJAX Requests
add_action('wp_ajax_send_message_to_openrouter', 'handle_openrouter_chat_request');
add_action('wp_ajax_nopriv_send_message_to_openrouter', 'handle_openrouter_chat_request');

function handle_openrouter_chat_request() {
    // Verify the AJAX nonce for security
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'openrouter_chat_nonce')) {
        wp_send_json_error('Invalid security token.');
    }

    // Get the user's message and sanitize it
    $user_message = sanitize_text_field($_POST['message'] ?? '');
    if (empty($user_message)) {
        wp_send_json_error('Message cannot be empty.');
    }

    // Retrieve the OpenRouter API key from settings
    $api_key = get_option('openrouter_api_key');
    if (empty($api_key)) {
        wp_send_json_error('API key not configured.');
    }

    // Define the API endpoint and headers
    $url = 'https://openrouter.ai/api/v1/chat/completions';
    $headers = array(
        'Authorization' => 'Bearer ' . $api_key,
        'Content-Type'  => 'application/json',
    );

    // Prepare the payload for the API request
    $body = array(
        'model'    => 'qwen/qwq-32b:free', // Use the correct model ID
        'messages' => array(
            array('role' => 'user', 'content' => $user_message),
        ),
    );

    // Retry logic
    $max_retries = 3;
    $retry_delay = 2; // Seconds between retries
    $success = false;

    for ($attempt = 1; $attempt <= $max_retries; $attempt++) {
        // Send the POST request to the OpenRouter API with an increased timeout
        $response = wp_remote_post($url, array(
            'headers' => $headers,
            'body'    => json_encode($body),
            'timeout' => 15, // Increase the timeout to 15 seconds
        ));

        // Check if the request was successful
        if (!is_wp_error($response)) {
            $success = true;
            break; // Exit the retry loop if successful
        }

        // Wait before retrying
        sleep($retry_delay);
    }

    // If all retries fail, return an error
    if (!$success) {
        wp_send_json_error('Error communicating with OpenRouter API after multiple attempts.');
    }

    // Decode the API response
    $response_body = json_decode(wp_remote_retrieve_body($response), true);


    // Validate the API response structure
    if (!isset($response_body['choices']) || !is_array($response_body['choices']) || empty($response_body['choices'])) {
        wp_send_json_error('Unexpected API response format: Missing or invalid "choices" array.');
    }

    // Extract the first choice from the response
    $first_choice = $response_body['choices'][0];
    if (!isset($first_choice['message']['content'])) {
        wp_send_json_error('Unexpected API response format: Missing "content" field.');
    }

    // Extract the bot's response
    $bot_response = $first_choice['message']['content'];

    // Return the bot's response as a success JSON response
    wp_send_json_success(array('response' => $bot_response));
}

// Add Settings Page for API Key
add_action('admin_menu', 'add_openrouter_settings_page');

function add_openrouter_settings_page() {
    add_options_page(
        'OpenRouter Chat Settings',
        'OpenRouter Chat',
        'manage_options',
        'openrouter-chat-settings',
        'render_openrouter_settings_page'
    );
}

function render_openrouter_settings_page() {
    if (isset($_POST['submit'])) {
        update_option('openrouter_api_key', sanitize_text_field($_POST['api_key']));
    }

    $api_key = get_option('openrouter_api_key');
    ?>
    <div class="wrap">
        <h1>OpenRouter Chat Settings</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="api_key">OpenRouter API Key</label></th>
                    <td><input type="text" id="api_key" name="api_key" value="<?php echo esc_attr($api_key); ?>" /></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="submit" class="button-primary" value="Save Changes" /></p>
        </form>
    </div>
    <?php
}
jQuery(document).ready(function($) {
    $('#send-message').on('click', function() {
        const userMessage = $('#user-message').val().trim();
        if (!userMessage) return;

        $.ajax({
            url: openrouter_chat_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'send_message_to_openrouter',
                message: userMessage,
                nonce: openrouter_chat_ajax.nonce,
            },
            success: function(response) {
                if (response.success) {
                    const botResponse = response.data.response;
                    $('#chat-box').append('<p><strong>You:</strong> ' + userMessage + '</p>');
                    $('#chat-box').append('<p><strong>Qwen:</strong> ' + botResponse + '</p>');
                    $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
                    $('#user-message').val('');
                } else {
                    alert('Error: ' + response.data);
                }
            },
            error: function() {
                alert('An error occurred while processing your request.');
            },
        });
    });
});